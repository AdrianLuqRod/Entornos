package Unidad3.tarea3;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException() {
		super();
	}
}
